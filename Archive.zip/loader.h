#include <stdio.h>
#include <stdlib.h>
#include "nivel.h"
// void print_nivel(Nivel nivel);
Nivel load_level (char *filename);